var createError = require('http-errors');
var express = require('express');
var path = require('path');
var ejs = require('ejs');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');
var fs = require('fs');
var sql = require('./database/DBconfig.js');
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var app = express();
// view engine setup

app.engine('.html',require('ejs').__express);
app.set('view engine', 'html');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.set('views','./views/');
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
/*app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});*/



// display user
app.get('/select',function(req,res){
        sql.query('select * from user',function(err,result){
          if (err) {
            res.render('select',{title:"用户列表",datas:[]});
          }else{var f=0;
            for(var i=0;i<result.length;i++)
            if(result[i].username==req.body.name||result[i].userid==req.body.id)
            res.render('select',{title:"用户列表",datas:result[i]}),f=1;
            if(f==0){
              res.render('select',{title:"用户列表",datas:[]});
            }
          }
        });
});

// add user
app.get('/add',function(req,res){
  res.render('add');
});

app.post('/add',function(req,res){
  var name = req.body.name;
  var id = req.body.id;
  var result =req.body.result;
  sql.query('insert into user(username,userid,result) values("'+name+'","'+ id +'","'+ result +'")',function(err,result){
     if(err){
            res.send('新增失败'+err);
        }else {
            res.redirect('/');
        }
  });
});


module.exports = app;
