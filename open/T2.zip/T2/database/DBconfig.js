var mysql = require('mysql');

var pool = mysql.createPool({
      host     : '39.106.213.13',
      user     : 'root',
      password : 'hyc010815',
      database : 'users'
    });

exports.query = function(sql,data){
    pool.getConnection(function(err,connection){
        connection.query(sql,function(err,result){
              data(err,result);
              connection.release();
        });
    });
}