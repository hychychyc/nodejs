var express = require('express');

var router = express.Router();



var sql = require('./database/DBconfig.js');




//进行查询

router.post('/select',function(req,res){
  sql.query('select * from user',function(err,result){
    if (err) {
      res.render('select',{title:"用户列表",datas:[]});
    }else{var f=0;
      for(var i=0;i<result.length;i++)
      if(result[i].username==req.body.name||result[i].userid==req.body.id)
      res.render('select',{title:"用户列表",datas:result[i]}),f=1;
      if(f==0){
        res.render('select',{title:"用户列表",datas:[]});
      }
    }
  });
});
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
router.post('/add',function(req,res){
  var name = req.body.name;
  var id = req.body.id;
  var result =req.body.result;
  sql.query('insert into user(username,userid,result) values("'+name+'","'+ id +'","'+ result +'")',function(err,result){
     if(err){
            res.send('新增失败'+err);
        }else {
            res.redirect('/');
        }
  });
});

module.exports = router;
