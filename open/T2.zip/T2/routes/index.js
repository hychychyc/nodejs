var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/add', function(req, res, next) {
  res.render('add', { title: 'Express' });
});
router.get('/select', function(req, res, next) {
  res.render('select', { title: 'Express' });
});
var sql = require('./database/DBconfig.js');




//进行查询

router.post('/select',function(req,res){
  sql.query('select * from user',function(err,result){
    if (err) {
      res.send('查询失败'+err+'<br>'+'<form action="/select" method="get">'+
      '<input name="B2" type="submit" value="返回"><br>'+
      '</form>');
    }else{var f=0;var ans="";
      for(var i=0;i<result.length;i++)
      if(result[i].username==req.body.name||result[i].userid==req.body.id)
      ans+='姓名：'+result[i].username+'<br>'+'学号：'+result[i].userid+'<br>'+'结果：'+result[i].result+'<br>'+'<br>',f=1;
      if(f==1)res.send(ans+'<br>'+'<form action="/select" method="get">'+
      ' <input name="B2" type="submit" value="返回"><br>'+
      '</form>');
      //res.send('新增失败'+result[i]);
      if(f==0){
        res.send('无'+'<br>'+'<form action="/select" method="get">'+
        ' <input name="B2" type="submit" value="返回"><br>'+
        '</form>');
        //res.render('select',{title:"用户列表",datas:[]});
      }
    }
  });
});
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
router.post('/add',function(req,res){
  var name = req.body.name;
  var id = req.body.id;
  var result =req.body.result;
  if(name&&id&&result){
    sql.query('insert into user(username,userid,result) values("'+name+'","'+ id +'","'+ result +'")',function(err,result){
     if(err){
            res.send('新增失败'+err+'<br>'+'<form action="/add" method="get">'+
            ' <input name="B2" type="submit" value="返回"><br>'+
            '</form>');
        }else {
          res.send('新增成功'+'<br>'+'<form action="/add" method="get">'+
          ' <input name="B2" type="submit" value="返回"><br>'+
          '</form>');
            //res.redirect('/');
        }
  })
  }
  
  else{
    res.send('信息不全'+'<br>'+'<form action="/add" method="get">'+
    ' <input name="B2" type="submit" value="返回"><br>'+
    '</form>');
  }
});

module.exports = router;
